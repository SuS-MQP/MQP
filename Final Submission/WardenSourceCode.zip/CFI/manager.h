#include "threadPool.h"

void initManager(int maxWorkers);
int populateDataStructures(struct hashmap *hashmap);